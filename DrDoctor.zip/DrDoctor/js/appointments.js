var beginButton = document.getElementById("apptBeginBtn-1");
var patientDetailsBox = document.getElementById("apptPatientDetails-1");


beginButton.addEventListener("click", function() {
    if(patientDetailsBox.style.display = "none"){
        patientDetailsBox.style.display = "block";
    }
    
});


